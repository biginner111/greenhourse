#ifndef _SYSTICK_H
#define _SYSTICK_H
#include "stm32f10x.h"

void tim3_init(uint16_t prescaler);
void tim3_delay(uint16_t count);
void delay_us(uint16_t us);
void delay_ms(int ms);

#endif
