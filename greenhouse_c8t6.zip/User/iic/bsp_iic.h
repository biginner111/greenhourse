#ifndef _BSP_IIC_H
#define _BSP_IIC_H


#include "stm32f10x.h"
#include "system.h"


#define RCC_IIC_CLKCMD   RCC_APB2PeriphClockCmd
#define RCC_IIC_SDA_CLK  RCC_APB2Periph_GPIOB
#define RCC_IIC_SCL_CLK  RCC_APB2Periph_GPIOB
#define IIC_SDA_PIN     GPIO_Pin_5
#define IIC_SDA_PORT    GPIOB
#define IIC_SCL_PIN     GPIO_Pin_6
#define IIC_SCL_PORT    GPIOB

#define IIC_SDA_HIGH    (PBout(5)=1)
#define IIC_SDA_LOW     (PBout(5)=0)
#define IIC_SCL_HIGH    (PBout(6)=1)
#define IIC_SCL_LOW     (PBout(6)=0)

#define SDA_READ         PBin(5)

 void iic_gpio_init(void);
 void SDA_OUT_MODE(void);
 void SDA_IN_MODE(void);
 void IIC_START(void);
 void IIC_END(void);
 void IIC_SEND_ACK(void);
 void IIC_SEND_NACK(void);
 uint8_t IIc_wait_Ack(void);
 void IIc_Send_Byte(uint8_t txdata);
 uint8_t IIc_Recive_Byte(uint8_t ack);

#endif

