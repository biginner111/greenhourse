#ifndef _DHT11_H
#define _DHT11_H

#include "stm32f10x.h"
#include "system.h"


typedef struct
{
	uint8_t  humi_int;		//ʪ�ȵ���������
	uint8_t  humi_deci;	 	//ʪ�ȵ�С������
	uint8_t  temp_int;	 	//�¶ȵ���������
	uint8_t  temp_deci;	 	//�¶ȵ�С������
	uint8_t  check_sum;	 	//У���
		                 
} DHT11_Data_TypeDef;


#define      DHT11_Dout_SCK_APBxClock_FUN              RCC_APB2PeriphClockCmd
#define      DHT11_Dout_GPIO_CLK                       RCC_APB2Periph_GPIOA

#define      DHT11_Dout_GPIO_PORT                      GPIOA
#define      DHT11_Dout_GPIO_PIN                       GPIO_Pin_7

#define      DHT11_Dout_0	                           (PAout(7)=0)
#define      DHT11_Dout_1	                           (PAout(7)=1)
#define      DHT11_Dout_IN()	                       PAin(7)

extern DHT11_Data_TypeDef DHT11_DATA;
void    DHT11_Init  ( void );
uint8_t DHT11_Read_TempAndHumidity ( DHT11_Data_TypeDef * DHT11_Data );


#endif
