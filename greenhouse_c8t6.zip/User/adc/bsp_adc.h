#ifndef _ADC_H
#define _ADC_H

#include "stm32f10x.h"

//ʹ�õ�ADC�жϣ�����ʹ�õ�ģʽ������һ
#define ADC_1_CHANNEL_INTER       1
#define ADC_1_CHANNEL_DMA         0
#define ADC_MULTI_CHANNEL_DMA     0

#if ADC_1_CHANNEL_DMA
#define ADC_DMA_RXBUFF_SIZE  (2)
extern uint16_t ADC_DMA_RxBuff[ADC_DMA_RXBUFF_SIZE]; 
#elif ADC_MULTI_CHANNEL_DMA
#define ADC_DMA_RXBUFF_SIZE  (2)
extern uint32_t ADC_DMA_RxBuff[ADC_DMA_RXBUFF_SIZE]; 
#endif

void adc_init(void);
float ADC_TO_Voltage(void);

#endif
