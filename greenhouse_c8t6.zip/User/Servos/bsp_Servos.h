#ifndef _SERVORS_H
#define _SERVORS_H

#include "stm32f10x.h"

//#define RCC_APB1_CMD      RCC_APB1PeriphClockCmd
//#define RCC_TIM3_CLK      RCC_APB1Periph_TIM3
#define SERVOS_PSC               (72-1)
#define SERVOS_ARR               (20000-1)
//#define TIM3_PORT          TIM3

////ʱ�ӳ�ʼ��
//#define RCC_TIM3_CH3_CLKCMD   RCC_APB2PeriphClockCmd
//#define RCC_TIM3_CH3_CLK      RCC_APB2Periph_GPIOB

////GPIO����
//#define TIM3_CH3_PIN          GPIO_Pin_0
//#define TIM3_CH3_PORT         GPIOB

void servos_init(void);

void Servos_SetAngle(uint16_t angle);

#endif
